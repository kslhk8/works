package member.dao;

import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import member.bean.MemberDTO;
@Component("memberDAO")
public class MemberDAOMybatis implements MemberDAO {
	@Autowired
	SqlSession sqlSession;
	@Override
	public void insertMember(MemberDTO memberDTO) {
		sqlSession.insert("memberSQL.insertMember",memberDTO);
		
	}
	@Override
	public MemberDTO getMember(String id) {
		return sqlSession.selectOne("memberSQL.getMember",id);
	}
	@Override
	public MemberDTO checkLogin(String id, String pwd) {
		Map<String,String> map = new HashMap<String,String>();
		map.put("id", id);
		map.put("pwd", pwd);
		return sqlSession.selectOne("memberSQL.checkLogin",map);
	}
	@Override
	public int updateBasicInfo(Map map) {
		return sqlSession.update("memberSQL.updateBasicInfo", map);
	}
	@Override
	public String getId(Map<String, String> map) {
		return sqlSession.selectOne("memberSQL.getId",map);
	}

}
