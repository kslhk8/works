package member.dao;

import java.util.Map;

import member.bean.MemberDTO;

public interface MemberDAO {

	public MemberDTO getMember(String id);
	
	public void insertMember(MemberDTO memberDTO);

	public MemberDTO checkLogin(String id, String pwd);
	
	public int updateBasicInfo(Map map);

	public String getId(Map<String, String> map);

	
}
